import { Detection } from "@/hooks/useObjectDetection";

interface DetectionOverlayProps {
  detections: Detection[];
}

const DetectionOverlay = ({ detections }: DetectionOverlayProps) => {
  const getColorClass = (type: Detection["type"]) => {
    switch (type) {
      case "weapon":
      case "violence":
        return "border-destructive text-destructive bg-destructive/10";
      case "person":
        return "border-success text-success bg-success/10";
      default:
        return "border-primary text-primary bg-primary/10";
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none">
      {detections.map((detection, index) => (
        <div
          key={index}
          className={`absolute border-2 ${getColorClass(detection.type)} rounded-lg backdrop-blur-sm animate-pulse-glow`}
          style={{
            left: `${detection.bbox.x}%`,
            top: `${detection.bbox.y}%`,
            width: `${detection.bbox.width}%`,
            height: `${detection.bbox.height}%`,
          }}
        >
          <div className={`absolute -top-6 left-0 px-2 py-1 rounded text-xs font-mono font-bold ${getColorClass(detection.type)}`}>
            {detection.label} {Math.round(detection.confidence * 100)}%
          </div>
        </div>
      ))}
    </div>
  );
};

export default DetectionOverlay;
