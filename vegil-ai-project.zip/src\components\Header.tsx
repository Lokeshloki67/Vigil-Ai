import { Shield, Activity } from "lucide-react";

const Header = () => {
  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Shield className="h-8 w-8 text-primary animate-pulse-glow" />
              <Activity className="h-4 w-4 text-success absolute -bottom-1 -right-1 animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground font-mono">VEGIL AI</h1>
              <p className="text-xs text-muted-foreground">Urban Safety Monitoring</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary/50 border border-border">
              <div className="h-2 w-2 rounded-full bg-success animate-pulse" />
              <span className="text-sm font-mono text-foreground">AI ACTIVE</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
