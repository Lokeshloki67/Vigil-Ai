import { useRef, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Video, VideoOff, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import DetectionOverlay from "./DetectionOverlay";
import { useObjectDetection } from "@/hooks/useObjectDetection";

import { Detection } from "@/hooks/useObjectDetection";

interface LiveMonitorProps {
  onThreatDetected: (level: "LOW" | "HIGH") => void;
  onDetectionsUpdate: (detections: Detection[]) => void;
}

const LiveMonitor = ({ onThreatDetected, onDetectionsUpdate }: LiveMonitorProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const requestRef = useRef<number>();
  const lastUpdateTime = useRef<number>(0);
  const [isStreaming, setIsStreaming] = useState(false);
  const [detections, setDetections] = useState<Detection[]>([]);
  const { toast } = useToast();
  // USE REAL DETECTION HOOK
  const { detect, isLoading } = useObjectDetection();

  const startWebcam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 1280, height: 720 }
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;

        // Wait for video to be ready and playing
        videoRef.current.onplaying = () => {
          console.log("Webcam stream started playing, initiating AI...");
          setIsStreaming(true);
          detectFrame();
        };

        videoRef.current.onplay = () => {
            console.log("Webcam play event triggered");
        };

        toast({
          title: "Webcam Activated",
          description: "Real-time AI monitoring initiated.",
        });
      }
    } catch (error) {
      console.error("Webcam error:", error);
      toast({
        title: "Webcam Access Denied",
        description: "Please allow camera access to use live monitoring",
        variant: "destructive",
      });
    }
  };

  const stopWebcam = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsStreaming(false);
      setDetections([]);
      onDetectionsUpdate([]);
      onThreatDetected("LOW");

      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }

      toast({
        title: "Webcam Deactivated",
        description: "Live monitoring stopped",
      });
    }
  };

  const detectFrame = async () => {
    if (!videoRef.current || videoRef.current.paused || videoRef.current.ended) {
      if (videoRef.current && videoRef.current.srcObject) {
        requestRef.current = requestAnimationFrame(detectFrame);
      }
      return;
    }

    // Ensure video dimensions are valid before detection
    if (videoRef.current.readyState < 2) {
      requestRef.current = requestAnimationFrame(detectFrame);
      return;
    }

    try {
      // Final dimension check before sending to detector
      if (videoRef.current.videoWidth === 0 || videoRef.current.videoHeight === 0) {
        console.warn("Video dimensions still zero, retrying...");
        requestRef.current = requestAnimationFrame(detectFrame);
        return;
      }

      const result = await detect(videoRef.current);
      if (result && Array.isArray(result.detections)) {
        if (result.detections.length > 0) {
            console.log(`Detected: ${result.detections.map(d => d.label).join(', ')}`);
        }
        // Update local state (overlay) every frame
        setDetections(result.detections);
        
        // Throttle updates to Index.tsx (Dashboard) to prevent UI freezing and flickering
        const now = performance.now();
        if (now - lastUpdateTime.current > 500) {
          onDetectionsUpdate(result.detections);
          onThreatDetected(result.threatLevel);
          lastUpdateTime.current = now;
        }
      }
    } catch (err) {
      console.error("Detection loop error:", err);
    }

    if (videoRef.current && videoRef.current.srcObject) {
      requestRef.current = requestAnimationFrame(detectFrame);
    }
  };

  useEffect(() => {
    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, []);

  return (
    <Card className="border-border bg-card/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Video className="h-5 w-5 text-primary" />
          Live Webcam Monitoring
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Real-time AI counting people and detecting objects locally.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative aspect-video bg-secondary/50 rounded-lg overflow-hidden border-2 border-border">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />

          {/* Overlay draws boxes on top of video */}
          {isStreaming && <DetectionOverlay detections={detections} />}

          {!isStreaming && !isLoading && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center space-y-4">
                <Video className="h-16 w-16 text-muted-foreground mx-auto" />
                <p className="text-muted-foreground">Webcam not active</p>
              </div>
            </div>
          )}

          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/50 backdrop-blur-sm z-50">
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="h-8 w-8 text-primary animate-spin" />
                <p className="text-muted-foreground">Loading AI Model...</p>
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-center gap-4">
          <Button
            onClick={isStreaming ? stopWebcam : startWebcam}
            disabled={isLoading}
            variant={isStreaming ? "destructive" : "default"}
            size="lg"
            className={!isStreaming ? "bg-gradient-cyber hover:shadow-glow-primary" : ""}
          >
            {isStreaming ? (
              <>
                <VideoOff className="mr-2 h-4 w-4" />
                Stop Monitoring
              </>
            ) : (
              <>
                <Video className="mr-2 h-4 w-4" />
                Start Monitoring
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default LiveMonitor;
