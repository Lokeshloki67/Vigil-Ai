import { AlertTriangle, Shield, Users, Eye } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Detection } from "@/hooks/useObjectDetection";

interface ThreatDashboardProps {
  threatLevel: "LOW" | "HIGH";
  detections: Detection[];
}

const ThreatDashboard = ({ threatLevel, detections }: ThreatDashboardProps) => {
  const peopleCount = detections.filter(d => d.type === "person").length;
  const weaponsCount = detections.filter(d => d.type === "weapon").length;
  const violenceCount = detections.filter(d => d.type === "violence").length;

  const stats = [
    {
      title: "Threat Level",
      value: threatLevel,
      icon: AlertTriangle,
      color: threatLevel === "HIGH" ? "text-destructive" : "text-success",
      bgColor: threatLevel === "HIGH" ? "bg-destructive/10" : "bg-success/10",
    },
    {
      title: "People Detected",
      value: peopleCount,
      icon: Users,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Weapons Detected",
      value: weaponsCount,
      icon: Shield,
      color: weaponsCount > 0 ? "text-destructive" : "text-muted-foreground",
      bgColor: weaponsCount > 0 ? "bg-destructive/10" : "bg-muted/10",
    },
    {
      title: "Violence Detected",
      value: violenceCount,
      icon: Eye,
      color: violenceCount > 0 ? "text-warning" : "text-muted-foreground",
      bgColor: violenceCount > 0 ? "bg-warning/10" : "bg-muted/10",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
      {stats.map((stat, index) => (
        <Card
          key={stat.title}
          className="border-border bg-card/80 backdrop-blur-sm hover:shadow-glow-primary transition-all duration-300 animate-fade-in-up"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-foreground">
              {stat.title}
            </CardTitle>
            <div className={`p-2 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold font-mono ${stat.color}`}>
              {stat.value}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {stat.title === "Threat Level" ? "Current Status" : "Live Count"}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default ThreatDashboard;
