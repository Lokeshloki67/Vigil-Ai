import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, Play, Pause, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import DetectionOverlay from "./DetectionOverlay";
import { useObjectDetection, Detection } from "@/hooks/useObjectDetection";

interface VideoUploadProps {
  onThreatDetected: (level: "LOW" | "HIGH") => void;
  onDetectionsUpdate: (detections: Detection[]) => void;
}

const VideoUpload = ({ onThreatDetected, onDetectionsUpdate }: VideoUploadProps) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [detections, setDetections] = useState<Detection[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const requestRef = useRef<number>();

  const { toast } = useToast();
  // USE REAL DETECTION HOOK
  const { detect, isLoading, isAnalyzing } = useObjectDetection();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith("video/")) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      if (videoRef.current) {
        videoRef.current.src = url;
        videoRef.current.load();
      }
      setDetections([]);
      onDetectionsUpdate([]);
      onThreatDetected("LOW");
      setIsPlaying(false);

      toast({
        title: "Video Loaded",
        description: `${file.name} ready for analysis`,
      });
    } else {
      toast({
        title: "Invalid File",
        description: "Please select a valid video file",
        variant: "destructive",
      });
    }
  };

  const toggleAnalysis = () => {
    if (!videoRef.current || !selectedFile) return;

    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
      detectFrame();
    }
  };

  const detectFrame = async () => {
    if (!videoRef.current || videoRef.current.paused || videoRef.current.ended) {
      setIsPlaying(false);
      return;
    }

    const result = await detect(videoRef.current);

    if (result && Array.isArray(result.detections)) {
      setDetections(result.detections);
      onDetectionsUpdate(result.detections);
      onThreatDetected(result.threatLevel);
    }

    // Yield CPU to video decoder by delaying the next inference (target ~5 FPS)
    setTimeout(() => {
      requestRef.current = requestAnimationFrame(detectFrame);
    }, 200);
  };

  useEffect(() => {
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  return (
    <Card className="border-border bg-card/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Upload className="h-5 w-5 text-primary" />
          Video Upload Analysis
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Upload videos for real-time client-side AI detection.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative aspect-video bg-secondary/50 rounded-lg overflow-hidden border-2 border-border">
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            onEnded={() => setIsPlaying(false)}
            playsInline
            muted
          />

          {selectedFile && <DetectionOverlay detections={detections} />}

          {!selectedFile && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center space-y-4">
                <Upload className="h-16 w-16 text-muted-foreground mx-auto" />
                <p className="text-muted-foreground">No video selected</p>
              </div>
            </div>
          )}

          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/50 backdrop-blur-sm z-50">
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="h-8 w-8 text-primary animate-spin" />
                <p className="text-muted-foreground">Loading AI Model...</p>
              </div>
            </div>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          onChange={handleFileSelect}
          className="hidden"
        />

        <div className="flex justify-center gap-4">
          <Button
            onClick={() => fileInputRef.current?.click()}
            variant="outline"
            size="lg"
            className="border-primary text-primary hover:bg-primary/10"
          >
            <Upload className="mr-2 h-4 w-4" />
            Select Video
          </Button>

          <Button
            onClick={toggleAnalysis}
            disabled={!selectedFile || isLoading}
            size="lg"
            className={isPlaying ? "bg-red-500 hover:bg-red-600" : "bg-gradient-cyber hover:shadow-glow-primary"}
          >
            {isPlaying ? (
              <>
                <Pause className="mr-2 h-4 w-4" />
                Pause Analysis
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Start Analysis
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default VideoUpload;
