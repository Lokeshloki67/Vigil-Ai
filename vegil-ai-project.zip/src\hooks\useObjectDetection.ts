
import { useState, useEffect, useRef } from 'react';
import * as tf from '@tensorflow/tfjs';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
// Explicitly import backends to ensure they are registered
import '@tensorflow/tfjs-backend-webgl';
import '@tensorflow/tfjs-backend-cpu';
import { useToast } from "@/components/ui/use-toast";

export interface Detection {
    type: "person" | "weapon" | "violence" | "other";
    label: string;
    confidence: number;
    bbox: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    description?: string;
}

export interface AnalysisResult {
    detections: Detection[];
    threatLevel: "HIGH" | "LOW";
    summary: string;
    personCount: number;
}

const calculateIoU = (
    box1: {x: number, y: number, width: number, height: number}, 
    box2: {x: number, y: number, width: number, height: number}
) => {
    const x1 = Math.max(box1.x, box2.x);
    const y1 = Math.max(box1.y, box2.y);
    const x2 = Math.min(box1.x + box1.width, box2.x + box2.width);
    const y2 = Math.min(box1.y + box1.height, box2.y + box2.height);

    const intersectionArea = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
    
    const box1Area = box1.width * box1.height;
    const box2Area = box2.width * box2.height;
    
    const unionArea = box1Area + box2Area - intersectionArea;
    if (unionArea <= 0) return 0;
    
    return intersectionArea / unionArea;
};

export const useObjectDetection = () => {
    const [model, setModel] = useState<cocoSsd.ObjectDetection | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const isAnalyzingRef = useRef(false);
    const { toast } = useToast();

    useEffect(() => {
        let isMounted = true;

        const loadModel = async () => {
            try {
                console.log("Starting AI System initialization...");
                
                // 1. Initialize TFJS
                console.log("Checking TensorFlow.js readiness...");
                await tf.ready();
                
                // 2. Set Backend
                const backends = ['webgl', 'cpu'];
                let currentBackend = 'none';
                
                for (const backend of backends) {
                    try {
                        await tf.setBackend(backend);
                        currentBackend = tf.getBackend();
                        console.log(`TFJS Backend successfully set to: ${currentBackend}`);
                        break;
                    } catch (e) {
                        console.warn(`Failed to set backend to ${backend}:`, e);
                    }
                }

                if (currentBackend === 'none') {
                    throw new Error("No suitable TensorFlow.js backend found.");
                }

                // 3. Load COCO-SSD Model
                console.log("Loading COCO-SSD model...");
                const startTime = performance.now();
                
                // Add a timeout for model loading
                const loadPromise = cocoSsd.load({
                    base: 'mobilenet_v2'
                });
                const timeoutPromise = new Promise((_, reject) => 
                    setTimeout(() => reject(new Error("Model loading timed out")), 30000)
                );
                
                const loadedModel = await Promise.race([loadPromise, timeoutPromise]) as cocoSsd.ObjectDetection;
                const endTime = performance.now();
                console.log(`Model loaded successfully in ${Math.round(endTime - startTime)}ms`);

                // 4. Model Warmup
                console.log("Performing model warmup with zero tensor...");
                const dummyInput = tf.zeros([224, 224, 3], 'int32') as unknown as HTMLVideoElement;
                await loadedModel.detect(dummyInput);
                console.log("Model warmup complete");

                if (isMounted) {
                    setModel(loadedModel);
                    setIsLoading(false);
                    toast({
                        title: "AI System Ready",
                        description: `Neural engine initialized using ${currentBackend} backend.`,
                    });
                }
            } catch (error) {
                console.error("CRITICAL: AI Engine initialization failed:", error);
                if (isMounted) {
                    toast({
                        title: "System Error",
                        description: `Failed to initialize AI engine: ${error instanceof Error ? error.message : 'Unknown error'}. Please refresh.`,
                        variant: "destructive",
                    });
                    setIsLoading(false);
                }
            }
        };

        loadModel();

        return () => {
            isMounted = false;
        };
    }, [toast]);

    const detect = async (videoElement: HTMLVideoElement | HTMLImageElement): Promise<AnalysisResult | null> => {
        if (!model) {
            console.warn("Detection attempt before model is ready");
            return { detections: [], threatLevel: "LOW", summary: "Engine not ready", personCount: 0 };
        }
        
        if (isAnalyzingRef.current) return null;

        const inferenceStart = performance.now();
        isAnalyzingRef.current = true;
        setIsAnalyzing(true);
        
        try {
            // Validate video element dimensions
            const width = ('videoWidth' in videoElement) ? videoElement.videoWidth : (videoElement as HTMLImageElement).width;
            const height = ('videoHeight' in videoElement) ? videoElement.videoHeight : (videoElement as HTMLImageElement).height;

            if (!width || !height) {
                console.warn("Invalid video dimensions for detection:", width, height);
                return { detections: [], threatLevel: "LOW", summary: "Invalid input dimensions", personCount: 0 };
            }

            const predictions = await model.detect(videoElement);

            const detections: Detection[] = predictions.map(pred => {
                let className = pred.class.toLowerCase();
                // For demonstration purposes, we map objects often used to simulate weapons (like showing an image on a cell phone) to 'gun'
                if (['scissors', 'cell phone', 'remote', 'baseball bat', 'hair drier', 'toothbrush'].includes(className)) {
                    className = 'gun';
                }
                
                const weaponClasses = ['knife', 'gun', 'baseball bat', 'rifle', 'revolver'];
                const isWeapon = weaponClasses.includes(className);
                
                return {
                    type: className === 'person' ? 'person' : (isWeapon ? 'weapon' : 'other'),
                    label: className,
                    confidence: pred.score,
                    bbox: {
                        x: Math.max(0, (pred.bbox[0] / width) * 100),
                        y: Math.max(0, (pred.bbox[1] / height) * 100),
                        width: Math.min(100, (pred.bbox[2] / width) * 100),
                        height: Math.min(100, (pred.bbox[3] / height) * 100)
                    },
                    description: `${className} detected (${Math.round(pred.score * 100)}%)`
                };
            }).filter((d): d is Detection => d.type !== 'other');

            const people = detections.filter(d => d.type === 'person');
            const weapons = detections.filter(d => d.type === 'weapon');

            const personCount = people.length;
            let isHighThreat = weapons.length > 0;
            let isViolence = false;

            // Heuristic for detecting fighting
            if (personCount >= 3) {
                // Check if any two people have significantly overlapping bounding boxes
                for (let i = 0; i < people.length; i++) {
                    for (let j = i + 1; j < people.length; j++) {
                        const iou = calculateIoU(people[i].bbox, people[j].bbox);
                        // A 15% overlap usually means they are physically interacting
                        if (iou > 0.15) { 
                            isViolence = true;
                            isHighThreat = true;
                            break;
                        }
                    }
                    if (isViolence) break;
                }
            }
            
            if (isViolence) {
                // Add a violence detection event so the Threat Dashboard correctly tallies it
                detections.push({
                    type: "violence",
                    label: "violence/fighting",
                    confidence: 1.0,
                    bbox: { x: 5, y: 5, width: 10, height: 5 }, // Placing tag out of the way
                    description: "Physical altercation detected"
                });
            }

            const summary = isHighThreat
                ? (isViolence ? `CRITICAL: Physical fighting/violence detected!` : `CRITICAL THREAT: ${weapons.map(w => w.label).join(', ')} detected!`)
                : `Monitoring: ${personCount} person(s) detected.`;

            if (isHighThreat) {
                toast({
                    title: "⚠️ WEAPON DETECTED",
                    description: summary,
                    variant: "destructive",
                });
            }

            const inferenceEnd = performance.now();
            if (detections.length > 0) {
                console.log(`Inference: ${Math.round(inferenceEnd - inferenceStart)}ms | Objects: ${detections.length} | People: ${personCount}`);
            }

            return {
                detections,
                threatLevel: isHighThreat ? "HIGH" : "LOW",
                summary,
                personCount
            };

        } catch (error) {
            console.error("Detection error:", error);
            return { detections: [], threatLevel: "LOW", summary: "Error during detection", personCount: 0 };
        } finally {
            isAnalyzingRef.current = false;
            setIsAnalyzing(false);
        }
    };

    return { model, isLoading, detect, isAnalyzing };
};
