import { useState } from "react";
import Header from "@/components/Header";
import LiveMonitor from "@/components/LiveMonitor";
import VideoUpload from "@/components/VideoUpload";
import ThreatDashboard from "@/components/ThreatDashboard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Detection } from "@/hooks/useObjectDetection";

const Index = () => {
  const [threatLevel, setThreatLevel] = useState<"LOW" | "HIGH">("LOW");
  const [detections, setDetections] = useState<Detection[]>([]);

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Animated Background Grid */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />

      {/* Scanning Line Effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-primary to-transparent opacity-50 animate-scan-line" />
      </div>

      <div className="relative z-10">
        <Header />

        <main className="container mx-auto px-4 py-8 space-y-8">
          {/* Hero Section */}
          <div className="text-center space-y-4 animate-fade-in-up">
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-cyber bg-clip-text text-transparent animate-pulse-glow">
              VEGIL AI
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Proactive Urban Safety Through AI-Enhanced CCTV Monitoring
            </p>
            <div className="flex items-center justify-center gap-2 text-sm">
              <div className="flex items-center gap-2">
                <div className={`h-3 w-3 rounded-full ${threatLevel === "HIGH" ? "bg-destructive animate-pulse" : "bg-success"} shadow-glow-primary`} />
                <span className="font-mono text-foreground">
                  SYSTEM STATUS: <span className={threatLevel === "HIGH" ? "text-destructive" : "text-success"}>
                    {threatLevel === "HIGH" ? "THREAT DETECTED" : "OPERATIONAL"}
                  </span>
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              {/* Main Content Tabs */}
              <Tabs defaultValue="live" className="w-full animate-zoom-in">
                <TabsList className="grid w-full grid-cols-2 bg-card/50 backdrop-blur-sm border border-border">
                  <TabsTrigger value="live" className="data-[state=active]:bg-gradient-cyber data-[state=active]:text-primary-foreground">
                    Live Monitor
                  </TabsTrigger>
                  <TabsTrigger value="upload" className="data-[state=active]:bg-gradient-cyber data-[state=active]:text-primary-foreground">
                    Video Analysis
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="live" className="mt-6">
                  <LiveMonitor
                    onThreatDetected={setThreatLevel}
                    onDetectionsUpdate={setDetections}
                  />
                </TabsContent>

                <TabsContent value="upload" className="mt-6">
                  <VideoUpload
                    onThreatDetected={setThreatLevel}
                    onDetectionsUpdate={setDetections}
                  />
                </TabsContent>
              </Tabs>
            </div>
            
            <div className="lg:col-span-1 space-y-6">
              {/* Threat Dashboard */}
              <ThreatDashboard threatLevel={threatLevel} detections={detections} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Index;
