import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageData } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    if (!imageData) {
      throw new Error('No image data provided');
    }

    console.log('Analyzing image for threats...');

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: `You are an advanced AI security system analyzing surveillance footage for threats. Your job is to:
1. Detect all people in the frame with high accuracy
2. Identify any weapons (guns, knives, blades, or dangerous objects)
3. Detect violent behavior (fighting, aggressive actions, physical altercations)
4. Detect suspicious activities

Respond ONLY with valid JSON in this exact format:
{
  "detections": [
    {
      "type": "person" | "weapon" | "violence",
      "label": "descriptive label",
      "confidence": 0.0-1.0,
      "bbox": {"x": number, "y": number, "width": number, "height": number},
      "description": "brief description"
    }
  ],
  "threatLevel": "HIGH" | "LOW",
  "summary": "brief analysis summary"
}

CRITICAL RULES:
- Always provide realistic bounding box coordinates (x, y, width, height in pixels)
- HIGH threat only if weapons or violence detected
- Be accurate and thorough in detection`
          },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'Analyze this surveillance image for threats. Detect people, weapons, violence, and any suspicious activity. Provide accurate bounding boxes.'
              },
              {
                type: 'image_url',
                image_url: {
                  url: imageData
                }
              }
            ]
          }
        ],
        temperature: 0.3,
        max_tokens: 1000,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI Gateway error:', response.status, errorText);
      throw new Error(`AI Gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log('AI Response received');
    
    const aiContent = data.choices[0].message.content;
    console.log('Raw AI content:', aiContent);

    // Parse the JSON response from AI
    let analysisResult;
    try {
      // Extract JSON from markdown code blocks if present
      const jsonMatch = aiContent.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || 
                       aiContent.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? (jsonMatch[1] || jsonMatch[0]) : aiContent;
      analysisResult = JSON.parse(jsonString);
    } catch (parseError) {
      console.error('Failed to parse AI response:', parseError);
      // Return a default safe response
      analysisResult = {
        detections: [],
        threatLevel: 'LOW',
        summary: 'Unable to analyze image properly'
      };
    }

    console.log('Analysis result:', analysisResult);

    return new Response(JSON.stringify(analysisResult), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in analyze-threat function:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        detections: [],
        threatLevel: 'LOW',
        summary: 'Analysis error occurred'
      }), 
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
